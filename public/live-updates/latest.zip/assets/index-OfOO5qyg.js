const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-CBW8J6Tb.js","assets/index-CFssgU3O.js","assets/index-CHmS9cnM.css"])))=>i.map(i=>d[i]);
import{r as t,_ as i}from"./index-CFssgU3O.js";const _=t("LiveUpdate",{web:()=>i(()=>import("./web-CBW8J6Tb.js"),__vite__mapDeps([0,1,2])).then(e=>new e.LiveUpdateWeb)});export{_ as LiveUpdate};
