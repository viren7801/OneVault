const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-pfEmreo5.js","assets/index-BQQr8oPd.js","assets/index-DrMyHLVX.css"])))=>i.map(i=>d[i]);
import{r as t,_ as i}from"./index-BQQr8oPd.js";const _=t("LiveUpdate",{web:()=>i(()=>import("./web-pfEmreo5.js"),__vite__mapDeps([0,1,2])).then(e=>new e.LiveUpdateWeb)});export{_ as LiveUpdate};
