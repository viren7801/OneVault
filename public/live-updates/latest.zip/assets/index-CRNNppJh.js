const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-C3gYuq5j.js","assets/index-PLZMb4Ad.js","assets/index-CAPwcKnI.css"])))=>i.map(i=>d[i]);
import{r as t,_ as i}from"./index-PLZMb4Ad.js";const _=t("LiveUpdate",{web:()=>i(()=>import("./web-C3gYuq5j.js"),__vite__mapDeps([0,1,2])).then(e=>new e.LiveUpdateWeb)});export{_ as LiveUpdate};
