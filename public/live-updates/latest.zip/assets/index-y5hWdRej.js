const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-BScHppVu.js","assets/index-pPZse2U2.js","assets/index-CLRDl3Gb.css"])))=>i.map(i=>d[i]);
import{r as t,_ as i}from"./index-pPZse2U2.js";const _=t("LiveUpdate",{web:()=>i(()=>import("./web-BScHppVu.js"),__vite__mapDeps([0,1,2])).then(e=>new e.LiveUpdateWeb)});export{_ as LiveUpdate};
