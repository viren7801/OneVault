const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-DP3_-S9a.js","assets/index-CCGxk5Hf.js","assets/index-CLRDl3Gb.css"])))=>i.map(i=>d[i]);
import{r as t,_ as i}from"./index-CCGxk5Hf.js";const _=t("LiveUpdate",{web:()=>i(()=>import("./web-DP3_-S9a.js"),__vite__mapDeps([0,1,2])).then(e=>new e.LiveUpdateWeb)});export{_ as LiveUpdate};
