const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-DLJx1L_V.js","assets/index-BYCV9vSI.js","assets/index-C59Hbmwy.css"])))=>i.map(i=>d[i]);
import{r as t,_ as i}from"./index-BYCV9vSI.js";const _=t("LiveUpdate",{web:()=>i(()=>import("./web-DLJx1L_V.js"),__vite__mapDeps([0,1,2])).then(e=>new e.LiveUpdateWeb)});export{_ as LiveUpdate};
